<template>
    <div>
        这是管理员列表
    </div>
</template>