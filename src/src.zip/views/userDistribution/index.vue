<template>
    <div>
        这是用户分布
    </div>
</template>