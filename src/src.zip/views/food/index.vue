<template>
    <div>
        这是食品列表
    </div>
</template>