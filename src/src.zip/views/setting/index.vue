<template>
    <div>
        这是管理员设置
    </div>
</template>