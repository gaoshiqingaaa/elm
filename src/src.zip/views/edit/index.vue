<template>
    <div>
        这是文本编辑
    </div>
</template>