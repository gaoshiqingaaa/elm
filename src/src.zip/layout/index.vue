<template>
  <div>
      <el-container style=" border: 1px solid #eee">
        <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
          <el-menu >
            <el-menu-item ><router-link to="/manage">首页</router-link></el-menu-item>
            <el-submenu index="1">
                <template slot="title"><i class="el-icon-document"></i>数据管理</template>
                <el-menu-item index="1-1"><router-link to="/user">用户列表</router-link></el-menu-item>
                <el-menu-item index="1-2"><router-link to="/shop">商家列表</router-link></el-menu-item>
                <el-menu-item index="1-3"><router-link to="/food">食品列表</router-link></el-menu-item>
                <el-menu-item index="1-4"><router-link to="/order">订单列表</router-link></el-menu-item>
                <el-menu-item index="1-5"><router-link to="/manager">管理员列表</router-link></el-menu-item>
            </el-submenu>
            <el-submenu index="2">
              <template slot="title"><i class="el-icon-plus"></i>添加数据</template>
              <el-menu-item index="2-1"><router-link to="/addShop">添加商铺</router-link></el-menu-item>
              <el-menu-item index="2-2"><router-link to="/addItem">添加商品</router-link></el-menu-item>
            </el-submenu>
            <el-submenu index="3">
              <template slot="title"><i class="el-icon-s-data"></i>图表</template>
                <el-menu-item index="3-1"><router-link to="/userDistribution">用户分布</router-link></el-menu-item>
            </el-submenu>
            <el-submenu index="4">
              <template slot="title"><i class="el-icon-edit"></i>编辑</template>
                <el-menu-item index="4-1"><router-link to="/edit">文本编辑</router-link></el-menu-item>
            </el-submenu>
            <el-submenu index="5">
              <template slot="title"><i class="el-icon-setting"></i>设置</template>
                <el-menu-item index="5-1"><router-link to="/setting">管理员设置</router-link></el-menu-item>
            </el-submenu>
            <el-submenu index="6">
              <template slot="title"><i class="el-icon-warning-outline"></i>说明</template>
                <el-menu-item index="6-1"><router-link to="/info">说明</router-link></el-menu-item>
            </el-submenu>
          </el-menu>
        </el-aside>
       
  <el-container>
    <el-header style="text-align: right; font-size: 12px">
      <el-dropdown>
        <i class="el-icon-setting" style="margin-right: 15px"></i>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item>查看</el-dropdown-item>
          <el-dropdown-item>新增</el-dropdown-item>
          <el-dropdown-item>删除</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
      <span>王小虎</span>
    </el-header>
    
    <el-main>
      <keep-alive>
          <router-view/>
      </keep-alive>
    </el-main>
  </el-container>
</el-container>
  </div>
</template>