<template>
    <div>
        <h3>{{msg}}</h3>
    </div>
</template>

<script>
export default {
    name: 'Test',
    data(){
        return {
            msg: '这是aaaaaaaaa测试'
        }    
    }
}
</script>

<style>

</style>